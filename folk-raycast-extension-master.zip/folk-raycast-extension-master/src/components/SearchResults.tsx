import { Detail } from "@raycast/api";

const SearchResults = () => {
  return <Detail markdown="# Search Contacts, Organizations & Groups! 🔍" />;
};

export default SearchResults;
